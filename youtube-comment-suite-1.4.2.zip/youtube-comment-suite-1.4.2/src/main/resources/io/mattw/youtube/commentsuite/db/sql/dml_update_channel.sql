UPDATE channels
SET channel_name = ?,
    channel_profile_url = ?
WHERE channel_id = ?;