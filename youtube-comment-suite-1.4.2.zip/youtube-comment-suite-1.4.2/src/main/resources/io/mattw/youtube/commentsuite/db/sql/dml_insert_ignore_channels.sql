INSERT OR IGNORE INTO channels (
    channel_id, channel_name, channel_profile_url, download_profile
) VALUES (?, ?, ?, ?);