package io.mattw.youtube.commentsuite;

import com.google.common.cache.Cache;
import com.google.common.cache.CacheBuilder;
import io.mattw.youtube.commentsuite.db.YouTubeObject;
import javafx.scene.image.Image;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import sun.security.krb5.Config;

import javax.imageio.ImageIO;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.net.URL;
import java.util.concurrent.TimeUnit;

/**
 * Cache for images and letter avatars.
 *
 * @author mattwright324
 */
public interface ImageCache {

    Logger logger = LogManager.getLogger();

    File thumbsDir = new File("thumbs/");
    String thumbFormat = "jpg";

    Cache<Object, Image> thumbCache = CacheBuilder.newBuilder()
            .maximumSize(500)
            .expireAfterAccess(5, TimeUnit.MINUTES)
            .build();

    static Image toLetterAvatar(YouTubeObject object) {
        return toLetterAvatar(object.getTitle());
    }

    static Image toLetterAvatar(String s) {
        if (s == null || s.isEmpty()) {
            return toLetterAvatar(" ");
        } else {
            return toLetterAvatar(s.charAt(0));
        }
    }

    static Image toLetterAvatar(char letter) {
        Image image = thumbCache.getIfPresent(letter);
        if (image == null) {
            image = new LetterAvatar(letter);
            thumbCache.put(letter, image);
        }
        return image;
    }

    static Image findOrGetImage(String id, String imageUrl) {
        ConfigFile<ConfigData> config = FXMLSuite.getConfig();
        ConfigData configData = config.getDataObject();

        if (ConfigData.FAST_GROUP_ADD_THUMB_PLACEHOLDER.equals(imageUrl)) {
            return null;
        }

        Image image = thumbCache.getIfPresent(id);
        if (image == null) {
            File thumbFile = new File(thumbsDir, String.format("%s.%s", id, thumbFormat));
            if (configData.isArchiveThumbs() && !thumbFile.exists()) {
                thumbsDir.mkdir();

                logger.debug("Archiving [id={}]", id);
                try {
                    BufferedImage bufferedImage = ImageIO.read(new URL(imageUrl));

                    thumbFile.createNewFile();

                    ImageIO.write(bufferedImage, thumbFormat, thumbFile);
                } catch (IOException e) {
                    logger.error("Failed to archive image [id={}]", id, e);
                }
            }
            if (thumbFile.exists()) {
                image = new Image(String.format("file:///%s", thumbFile.getAbsolutePath()));
            } else {
                image = new Image(imageUrl);
            }

            if(!image.isError()) {
                thumbCache.put(id, image);
            }
        }
        return image;
    }

    static Image findOrGetImage(YouTubeObject object) {
        return findOrGetImage(object.getId(), object.getThumbUrl());
    }

    static Image findOrGetImage(YouTubeAccount account) {
        return findOrGetImage(account.getChannelId(), account.getThumbUrl());
    }

    static boolean hasImageCached(YouTubeObject object) {
        return thumbCache.getIfPresent(object.getId()) != null;
    }
}
