package io.mattw.youtube.commentsuite.util;

/**
 * @author mattwright324
 */
public interface LocationProvider {
    String getRequestUrl(String ipv4);
}
