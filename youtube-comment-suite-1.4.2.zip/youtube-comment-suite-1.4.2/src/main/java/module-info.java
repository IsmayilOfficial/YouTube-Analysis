/*
 * Uncomment this to start the Java upgrade.
 *
 * Note: incomplete, has javafx modules but none of the other dependencies from pom.xml
 */
/*module io.mattw.youtube {
    requires javafx.fxml;
    requires javafx.controls;
    requires javafx.graphics;
    requires javafx.base;
    requires javafx.media;

    opens io.mattw.youtube;
}*/